package com.example.vmac.WatBot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;


public class ActivityHospitals extends AppCompatActivity {

    ImageView home;
    ImageView doct;
    ImageView treat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospitals);

        home = (ImageView) findViewById(R.id.homeActivity);
        doct = (ImageView) findViewById(R.id.doctorsActivity);
        treat = (ImageView) findViewById(R.id.treatments);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityHospitals.this, ActivityUser.class);
                startActivity(intent);
            }
        });

        doct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityHospitals.this, ActivityDoctors.class);
                startActivity(intent);
            }
        });

        treat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityHospitals.this, ActivityTreatments.class);
                startActivity(intent);
            }
        });
    }
}