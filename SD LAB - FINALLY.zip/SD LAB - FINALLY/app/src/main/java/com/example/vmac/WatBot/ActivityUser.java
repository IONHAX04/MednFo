package com.example.vmac.WatBot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ActivityUser extends AppCompatActivity {

    ImageView hosp;
    ImageView doct;
    ImageView treat;

    TextView order, order1, order2, order3, order4, order5, order6, order7, order8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        hosp = (ImageView) findViewById(R.id.hospActivity);
        doct = (ImageView) findViewById(R.id.doctorsActivity);
        treat = (ImageView) findViewById(R.id.treatments);


        order = (TextView) findViewById(R.id.placeOrder1);
        order1 = (TextView) findViewById(R.id.placeOrder2);
        order2 = (TextView) findViewById(R.id.placeOrder3);
        order3 = (TextView) findViewById(R.id.placeOrder4);
        order4 = (TextView) findViewById(R.id.placeOrder5);
        order5 = (TextView) findViewById(R.id.placeOrder6);
        order6 = (TextView) findViewById(R.id.placeOrder7);
        order7 = (TextView) findViewById(R.id.placeOrder8);
        order8 = (TextView) findViewById(R.id.placeOrder9);


        hosp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, ActivityHospitals.class);
                startActivity(intent);
            }
        });

        doct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, ActivityDoctors.class);
                startActivity(intent);
            }
        });

        treat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, ActivityTreatments.class);
                startActivity(intent);
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });

        order1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        order2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        order3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        order4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        order5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        order6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        order7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        order8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityUser.this, PaymentActivity.class);
                startActivity(intent);
            }
        });

    }
}