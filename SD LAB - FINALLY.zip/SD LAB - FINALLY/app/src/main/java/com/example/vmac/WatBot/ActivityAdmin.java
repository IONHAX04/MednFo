package com.example.vmac.WatBot;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.database.Cursor;
import java.util.ArrayList;

public class ActivityAdmin extends AppCompatActivity {

    ListView lst1;
    ArrayList<String> titles = new ArrayList<String>();
    ArrayAdapter arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        SQLiteDatabase db = openOrCreateDatabase("SliteDb", Context.MODE_PRIVATE, null);

        lst1 = findViewById(R.id.lst1);

        final Cursor c = db.rawQuery("select * from records", null);
        int id = c.getColumnIndex("id");
        int userAddress = c.getColumnIndex("userAddress");
        int userContact = c.getColumnIndex("userContact");
        int userCardName = c.getColumnIndex("userCardName");
        int userCardNumber = c.getColumnIndex("userCardNumber");
        int ccvNumber = c.getColumnIndex("ccvNumber");
        titles.clear();

        arrayAdapter = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, titles);
        lst1.setAdapter(arrayAdapter);

//        final ArrayList<student> stud = new ArrayList<student>();
    }
}