package com.example.vmac.WatBot;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.sql.Statement;

public class PaymentActivity extends AppCompatActivity {

    TextView pay1, pay2, bk1, bk2;

    EditText address, contact, cardNumber, cardHolder, ccv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        pay1 = (TextView) findViewById(R.id.placeOrders);
        pay2 = (TextView) findViewById(R.id.placeOrders1);
        bk1 = (TextView) findViewById(R.id.back);
        bk2 = (TextView) findViewById(R.id.back1);


        address = (EditText) findViewById(R.id.editAddress);
        contact = (EditText) findViewById(R.id.mobileEdittext);
        cardNumber = (EditText) findViewById(R.id.cardEdittext);
        cardHolder = (EditText) findViewById(R.id.cardNameEdittext);
        ccv = (EditText) findViewById(R.id.ccvEdittext);

        ;
        pay1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insert();
                Intent intent = new Intent(PaymentActivity.this, PaymentDone.class);
                startActivity(intent);
                finish();
            }
        });
        pay2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PaymentActivity.this, PaymentDone.class);
                startActivity(intent);
                finish();
            }
        });

        bk1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PaymentActivity.this, ActivityUser.class);
                startActivity(intent);
                finish();
            }
        });
        bk2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PaymentActivity.this, ActivityUser.class);
                startActivity(intent);
                finish();
            }
        });


    }

    public void insert(){
        try{
            String userAddress = address.getText().toString();
            String userContact = contact.getText().toString();
            String userCardNumber = cardNumber.getText().toString();
            String userCardName = cardHolder.getText().toString();
            String ccvNumber = ccv.getText().toString();

            SQLiteDatabase db = openOrCreateDatabase("DatabaseDb", Context.MODE_PRIVATE, null);
            db.execSQL("CREATE TABLE IF NOT EXISTS records (id INTEGER PRIMARY KEY AUTOINCREMENT, userAddress VARCHAR, userContact VARCHAR, userCardNumber VARCHAR, userCardName VARCHAR, ccvNumber VARCHAR)");

            String sql = "insert into records(userAddress, userContact, userCardNumber, userCardName, ccvNumber) values (?,?,?,?,?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, userAddress);
            statement.bindString(2, userContact);
            statement.bindString(3, userCardNumber);
            statement.bindString(4, userCardName);
            statement.bindString(5, ccvNumber);
            statement.execute();
            Toast.makeText(this, "Order Placed Successfully", Toast.LENGTH_LONG).show();

            address.setText("");
            contact.setText("");
            cardNumber.setText("");
            cardHolder.setText("");
            ccv.setText("");

            address.requestFocus();
        }
        catch (Exception ex){
            Toast.makeText(this, "Payment Failed, Try again", Toast.LENGTH_LONG).show();
        }
    }
}