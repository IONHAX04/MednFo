package com.example.vmac.WatBot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class ActivityDoctors extends AppCompatActivity {

    ImageView hosp;
    ImageView home;
    ImageView treat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors);

        hosp = (ImageView) findViewById(R.id.hospActivity);
        home = (ImageView) findViewById(R.id.homeActivity);
        treat = (ImageView) findViewById(R.id.treatments);

        hosp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityDoctors.this, ActivityHospitals.class);
                startActivity(intent);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityDoctors.this, ActivityUser.class);
                startActivity(intent);
            }
        });

        treat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityDoctors.this, ActivityTreatments.class);
                startActivity(intent);
            }
        });
    }
}