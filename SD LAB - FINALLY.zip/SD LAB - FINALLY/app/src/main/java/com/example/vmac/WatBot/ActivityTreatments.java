package com.example.vmac.WatBot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class ActivityTreatments extends AppCompatActivity {
    ImageView hosp;
    ImageView doct;
    ImageView home;

    Button app1, app2, app3, app4, app5, app6, app7, app8, app9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treatments);

        hosp = (ImageView) findViewById(R.id.hospActivity);
        doct = (ImageView) findViewById(R.id.doctorsActivity);
        home = (ImageView) findViewById(R.id.homeActivity);


        app1 = (Button) findViewById(R.id.appointment1);
        app2 = (Button) findViewById(R.id.appointment2);
        app3 = (Button) findViewById(R.id.appointment3);
        app4 = (Button) findViewById(R.id.appointment4);
        app5 = (Button) findViewById(R.id.appointment5);
        app6 = (Button) findViewById(R.id.appointment6);
        app7 = (Button) findViewById(R.id.appointment7);
        app8 = (Button) findViewById(R.id.appointment8);
        app9 = (Button) findViewById(R.id.appointment9);


        hosp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, ActivityHospitals.class);
                startActivity(intent);
            }
        });

        doct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, ActivityDoctors.class);
                startActivity(intent);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, ActivityUser.class);
                startActivity(intent);
            }
        });


        app1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
        app9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityTreatments.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}