package com.example.vmac.WatBot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.ActionMenuItemView;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.gms.identity.intents.model.UserAddress;

public class ActivityOptions extends AppCompatActivity {

    LinearLayout user , about, chatbot, testimonial;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);


        user = (LinearLayout) findViewById(R.id.user_login);
        about = (LinearLayout) findViewById(R.id.aboutUs);
        chatbot = (LinearLayout) findViewById(R.id.chatbotuh);
        testimonial = (LinearLayout) findViewById(R.id.test);


        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityOptions.this, ActivityUser.class);
                startActivity(intent);
            }
        });


        chatbot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityOptions.this, MainActivity.class);
                startActivity(intent);
            }
        });

        testimonial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityOptions.this, ActivityTestimonials.class);
                startActivity(intent);
            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityOptions.this, ActivityLabTest.class);
                startActivity(intent);
            }
        });
    }
}